# -*- coding: utf-8 -*-
from sklearn import preprocessing as pp
from sklearn.pipeline import Pipeline

"""
Une fonction qui renvoie la meilleure pipeline trouvée pour l'instant,
pour ce projet en particulier.
La pipeline résultante peut être utilisée comme le régresseur 
passé en paramètre.

regressor 
    Le régresseur à ajouter en fin de chaîne.
"""
def pipeline_factory(regressor) :
    steps = [("polynomial", pp.PolynomialFeatures()),
             ("regressor", regressor)]
    return Pipeline(steps)

"""
Partie de code utilisée pour tester les pipelines.
Absolument inutile en-dehors de ce fichier.
(et devrait même être effacée lors du rendu)
"""
if __name__ == "__main__" :
    
    import PipelineRanker as pr
    from sklearn.ensemble import GradientBoostingRegressor, ExtraTreesClassifier
    #from sklearn.tree import DecisionTreeRegressor
    from sklearn.cluster import FeatureAgglomeration
    from sklearn.feature_selection import SelectKBest, SelectFromModel
    
    import numpy as np
    
    # Paramètres généraux
    regressor = GradientBoostingRegressor(n_estimators = 50,
                                          loss = 'ls',
                                          learning_rate = 0.8,
                                          max_depth = 6)
    history = "./" + regressor.__class__.__name__ + "(4).txt"
    
    # Chargement des données
    # Marche lorsque le dossier public_data est dans celui du starting kit.
    # Le fichier model.py ne semble fonctionner que si les deux sont au même niveau,
    # il s'agit peut-être d'erreur d'organisation de ma part.
    # A priori il suffit de rajouter ../ en préfixe aux deux strings ci-dessous
    # en cas de problème.
    x = np.loadtxt("../public_data/air_train.data")
    y = np.loadtxt("../public_data/air_train.solution")
    
    # Séparation des données en deux
    middle = int(x.shape[0]/2)
    x_train = x[:middle, :]
    y_train = y[:middle]
    x_test = x[middle:, :]
    y_test = y[middle:]
    
    d = 2
    pipelines = [        
                 Pipeline([("degree=" + str(d), pp.PolynomialFeatures(degree=d))])
                 ] * 3
    
    ranker = pr.PipelineRanker(regressor, pipelines, history)
    ranker.rank(x_train, y_train, x_test, y_test)
    
    
    

